# HYBRID ATHLETE — version installable sur iPhone

Ce dossier contient l'application web et les fichiers nécessaires pour la rendre installable comme une app sur iPhone.

## Important
Le dossier est prêt à être publié, mais il n'est pas encore accessible par une URL publique. Il faut d'abord l'héberger sur un service HTTPS (par exemple GitHub Pages). Je ne peux pas publier sur un compte externe sans accès/autorisation.

## Publication simple avec GitHub Pages
1. Depuis un ordinateur ou le navigateur, connecte-toi à GitHub et crée un nouveau dépôt public nommé `hybrid-athlete`.
2. Décompresse cette archive.
3. Dans le dépôt, choisis **Add file > Upload files** et dépose tous les fichiers du dossier (index.html, manifest.webmanifest, service-worker.js, icon-192.png, icon-512.png).
4. Valide avec **Commit changes**.
5. Dans **Settings > Pages**, choisis **Deploy from a branch**, puis `main` et `/ (root)`, et enregistre.
6. GitHub fournira une adresse HTTPS du type `https://TON-PSEUDO.github.io/hybrid-athlete/`.

## Installation sur iPhone
1. Ouvre cette adresse dans Safari.
2. Appuie sur le bouton **Partager**.
3. Choisis **Sur l'écran d'accueil** puis **Ajouter**.

L'application s'ouvrira ensuite depuis son icône. Les données d'entraînement sont conservées localement dans le navigateur de l'appareil. Évite d'effacer les données du site si tu veux conserver ton historique.
